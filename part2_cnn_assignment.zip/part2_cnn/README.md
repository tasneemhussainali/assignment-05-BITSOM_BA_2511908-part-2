# Part 2: Computer Vision Problem Formulation and CNN Prototype

> **Dataset:** Intel Image Classification (6 classes: buildings, forest, glacier, mountain, sea, street)
> **Framework:** TensorFlow / Keras | Python 3.10+

---

## Project Structure

```
part2_cnn/
├── main.py                          ← Run everything from here
├── requirements.txt
├── README.md                        ← This file
├── src/
│   ├── task1_problem_identification.py
│   ├── task2_dataset_exploration.py
│   ├── task3_preprocessing.py
│   ├── task4_model.py
│   └── task5_training_evaluation.py
├── data/                            ← Place your dataset here
│   ├── buildings/
│   ├── forest/
│   ├── glacier/
│   ├── mountain/
│   ├── sea/
│   └── street/
└── outputs/                         ← All plots saved here
    ├── class_distribution.png
    ├── sample_images.png
    ├── augmentation_demo.png
    ├── model_architecture.png
    ├── training_curves.png
    ├── confusion_matrix.png
    └── sample_predictions.png
```

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Place your dataset in the data/ folder
#    (each class in its own subfolder)

# 3. Run the full pipeline
python main.py
```

To run individual tasks:
```bash
python src/task1_problem_identification.py
python src/task2_dataset_exploration.py
python src/task3_preprocessing.py
python src/task4_model.py
```

---

## Task 1: Problem Identification

**Problem Type: IMAGE CLASSIFICATION**

The dataset contains images organized into **6 labeled folders**, one per scene category. Each image has a single global label — there are no bounding boxes, pixel masks, or per-object annotations.

| Problem Type           | Chosen? | Why / Why Not                                              |
|------------------------|---------|-------------------------------------------------------------|
| Image Classification   | ✅ YES  | Each image = one label; folder structure = classification setup |
| Object Detection       | ❌ No   | No bounding box coordinates in the dataset                 |
| Semantic Segmentation  | ❌ No   | No pixel-level labels; no per-pixel class maps             |
| Instance Segmentation  | ❌ No   | No object masks; far more annotation than available         |

**Conclusion:** This is a **6-class multi-class image classification** task. CNNs are ideal because they learn spatial hierarchies of visual patterns — from simple edges at early layers to complex textures and object parts at deeper layers.

---

## Task 2: Dataset Exploration

### Class Overview

| Class      | Images | % of Total |
|------------|--------|------------|
| Buildings  | ~2,191 | ~16.4%     |
| Forest     | ~2,271 | ~17.0%     |
| Glacier    | ~2,404 | ~18.0%     |
| Mountain   | ~2,512 | ~18.8%     |
| Sea        | ~2,274 | ~17.0%     |
| Street     | ~2,382 | ~17.8%     |
| **Total**  | **~14,034** | 100%  |

### Image Properties
- **Dimensions:** Approximately 150 × 150 pixels (varies; we standardize during preprocessing)
- **Color Mode:** RGB (3 channels)
- **Format:** JPEG / PNG

### Imbalance Analysis
- **Imbalance ratio:** ~1.15× (max class / min class)
- **Assessment:** **LOW imbalance** — all classes are roughly balanced, no special handling required

> See `outputs/class_distribution.png` and `outputs/sample_images.png`

---

## Task 3: Image Preprocessing

### Steps Applied

| Step              | Detail                                                                 |
|-------------------|------------------------------------------------------------------------|
| **Resize**        | All images resized to **150 × 150 px** (fixed input size for CNN)      |
| **Normalize**     | Pixel values scaled from **[0, 255] → [0.0, 1.0]**                   |
| **Train/Val/Test split** | **70% train / 15% validation / 15% test** (stratified split)  |
| **Augmentation**  | Applied only to training set (see below)                               |

### Data Augmentation (Training Only)

Augmentation artificially increases training data diversity and reduces overfitting:

| Augmentation        | Parameter              | Purpose                               |
|---------------------|------------------------|---------------------------------------|
| `RandomFlip`        | Horizontal             | Handles mirror images                 |
| `RandomRotation`    | ±15°                   | Rotation invariance                   |
| `RandomZoom`        | ±10%                   | Scale variation                       |
| `RandomTranslation` | ±10% horizontal/vertical | Position shift invariance           |
| `RandomContrast`    | ±10%                   | Lighting/contrast variation           |

> See `outputs/augmentation_demo.png`

---

## Task 4: CNN Model Architecture

```
Input: (150, 150, 3)
│
├─ Conv2D(32, 3×3, relu) → BatchNorm → MaxPool(2×2)    [Block 1 — edges, colors]
├─ Conv2D(64, 3×3, relu) → BatchNorm → MaxPool(2×2)    [Block 2 — textures]
├─ Conv2D(128, 3×3, relu) → BatchNorm → MaxPool(2×2)   [Block 3 — shapes]
├─ Conv2D(128, 3×3, relu) → BatchNorm → MaxPool(2×2)   [Block 4 — high-level parts]
│
├─ Flatten()
├─ Dense(512, relu) → Dropout(0.5)
└─ Dense(6, softmax)                                   [Output: 6 class probabilities]
```

**Optimizer:** Adam (lr = 0.001)
**Loss:** Sparse Categorical Cross-Entropy
**Metric:** Accuracy

> See `outputs/model_architecture.png`

---

## Task 5: Model Training and Evaluation

### Training Configuration

| Setting          | Value              |
|------------------|--------------------|
| Max epochs       | 30                 |
| Early stopping   | val_loss, patience=7 |
| LR reduction     | ReduceLROnPlateau, factor=0.5 |
| Best model saved | `outputs/best_model.keras` |

### Expected Results (Intel Image Classification Dataset)

| Metric               | Approx. Value |
|----------------------|---------------|
| Training Accuracy    | ~90–94%       |
| Validation Accuracy  | ~85–90%       |
| Test Accuracy        | ~84–89%       |

> Charts: `outputs/training_curves.png`, `outputs/confusion_matrix.png`, `outputs/sample_predictions.png`

---

## Task 6: CNN Concepts Explained

### What is Convolution?

Convolution is the core operation that makes CNNs work. Imagine sliding a small **filter** (e.g., 3×3 pixels) across every position of the input image. At each position, the filter performs a dot product with the image patch — multiplying each filter value with the corresponding pixel and summing the results. This produces a single number that represents *how strongly that pattern exists at that location*.

For example:
- A filter tuned to **vertical edges** produces high values wherever the image has a sharp left-to-right brightness change
- A filter tuned to **curves** lights up wherever curved shapes appear

By stacking many filters (32, 64, 128...) across multiple layers, the CNN builds up a rich vocabulary — from simple edges in early layers to complex scene components (sky, water, foliage) in deeper layers — without us ever manually specifying what to look for.

```
Image patch × Filter weights → Single feature value
Repeat across all positions → Feature map
Stack many filters → Multiple feature maps (channels)
```

---

### Why is Pooling Used?

After convolution, the feature maps are still large and spatially sensitive — a tiny shift in the image produces a different output. **Pooling** addresses three problems at once:

1. **Dimensionality reduction:** MaxPool(2×2) halves the height and width, cutting computation by 75% per layer
2. **Translation invariance:** By taking the maximum in a 2×2 window, the network stops caring *exactly* where a feature appeared — only *whether* it appeared nearby
3. **Overfitting reduction:** Fewer parameters → less memorization of training data

> **MaxPooling** specifically takes the largest value in each 2×2 window, preserving the strongest signal and discarding spatial noise.

---

### Why is ReLU Commonly Used in CNNs?

**ReLU (Rectified Linear Unit)** is defined as: `f(x) = max(0, x)`

It is the most popular activation function in CNNs for four reasons:

| Reason | Explanation |
|--------|-------------|
| **Non-linearity** | Without activation functions, stacking layers is mathematically equivalent to a single linear transformation — the network can't learn complex patterns |
| **Sparse activation** | ReLU sets all negative values to 0, meaning only some neurons fire for any input — this is computationally efficient and acts as implicit regularization |
| **Vanishing gradient fix** | Sigmoid and tanh squash gradients toward 0 for large inputs, making deep networks hard to train. ReLU has a constant gradient of 1 for positive inputs — gradients flow freely during backpropagation |
| **Computational simplicity** | ReLU is just a comparison and zero operation — orders of magnitude faster than sigmoid (`e^x`) in both forward and backward passes |

---

### Why are CNNs Better than Regular Feed-Forward Networks for Images?

A regular **fully-connected (FC) network** connects every neuron to every input pixel. For a 150×150 RGB image that's **67,500 input values** — just the first hidden layer with 1,000 neurons would require **67.5 million parameters**. This leads to:
- Massive memory and compute requirements
- Severe overfitting (too many parameters, too little signal)
- No spatial awareness — every pixel is treated independently

CNNs solve this through three structural innovations:

| Property | How CNNs Achieve It | Benefit |
|----------|---------------------|---------|
| **Local connectivity** | Each filter covers only a small patch (e.g., 3×3) | Far fewer parameters; focuses on local patterns |
| **Parameter sharing** | Same filter weights are used at every position | A "forest detector" works anywhere in the image |
| **Hierarchical features** | Early layers → edges; middle → textures; deep → objects | Learns visual hierarchy the same way human vision works |
| **Translation invariance** | Convolution + Pooling | Same object is recognized regardless of where in the frame it appears |

In short: **CNNs treat images as structured 2D grids** and exploit spatial locality, whereas FC networks treat them as flat, orderless bags of pixel values.

---

## Task 7: Business Use Case Mapping

### Domain: Agriculture 🌾

**Application: Crop Disease Detection from Field Images**

Modern farming faces a critical challenge: plant diseases can wipe out entire harvests before farmers visually identify the problem. A CNN-based image classification system trained on leaf and crop images can detect diseases early, automatically, and at scale.

**How It Works:**
1. Farmers or drones capture images of crop fields
2. The CNN classifies each image into categories: Healthy, Bacterial Blight, Leaf Rust, Powdery Mildew, etc.
3. Alerts are sent to farmers' mobile phones with location data and treatment recommendations

**Real-World Impact:**

| Metric | Without AI | With CNN System |
|--------|------------|-----------------|
| Disease detection lag | 2–3 weeks (visual inspection) | 24–48 hours |
| Area covered per day | 5–10 acres (manual) | 500+ acres (drone + AI) |
| False positive rate | High (human fatigue) | <5% (with trained model) |
| Yield loss prevented | 10–15% crop loss typical | Reduced to <3% with early intervention |

**Extensions:**
- Weed detection and precision herbicide spraying (reduces chemical use by 30–50%)
- Fruit ripeness grading for automated harvesting robots
- Soil quality mapping from aerial imagery
- Livestock health monitoring (skin condition, posture analysis)

**Why CNN is Ideal:**
Agricultural image data is inherently visual and spatial — disease patterns, color changes, and texture abnormalities are exactly the hierarchical features CNNs are designed to extract. Unlike manual inspection, a trained model applies consistent criteria 24/7 across millions of images, is unaffected by lighting variation (with augmentation), and improves continuously as more labeled data is collected.

---

## References

- LeCun, Y., et al. (1998). "Gradient-Based Learning Applied to Document Recognition." *Proceedings of the IEEE*
- Intel Image Classification Dataset — Kaggle
- TensorFlow Documentation: https://www.tensorflow.org/api_docs
- Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press
