"""
Task 4: CNN Model Creation
===========================
Builds a CNN using TensorFlow/Keras with:
  - Convolution layers
  - ReLU activation functions
  - MaxPooling layers
  - Flatten layer
  - Dense (fully connected) layers
  - Dropout for regularization
  - Softmax output layer
"""

import os
import tensorflow as tf
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def build_cnn(num_classes: int, img_size=(150, 150, 3)) -> tf.keras.Model:
    """
    Constructs the CNN architecture.

    Architecture Overview:
    ─────────────────────────────────────────────────
    Input (150×150×3)
      │
      ▼ Conv2D(32, 3×3) → ReLU → MaxPool(2×2)     [BLOCK 1]
      │   learns low-level features: edges, colors
      ▼ Conv2D(64, 3×3) → ReLU → MaxPool(2×2)     [BLOCK 2]
      │   learns mid-level features: textures, shapes
      ▼ Conv2D(128, 3×3) → ReLU → MaxPool(2×2)    [BLOCK 3]
      │   learns high-level features: object parts
      ▼ Conv2D(128, 3×3) → ReLU → MaxPool(2×2)    [BLOCK 4]
      │   even more abstract representations
      ▼ Flatten()
      ▼ Dense(512) → ReLU → Dropout(0.5)           [FC]
      ▼ Dense(num_classes) → Softmax               [OUTPUT]
    ─────────────────────────────────────────────────
    """

    model = tf.keras.Sequential([

        # ── INPUT ──────────────────────────────────────────
        tf.keras.layers.Input(shape=img_size),

        # ── BLOCK 1: Edge & Color Detection ────────────────
        # Conv2D: 32 filters, 3×3 kernel, 'same' padding keeps spatial size
        tf.keras.layers.Conv2D(32, (3, 3), padding="same", activation="relu",
                               name="conv1"),
        # BatchNorm stabilizes training by normalizing layer outputs
        tf.keras.layers.BatchNormalization(name="bn1"),
        # MaxPool: halves spatial dimensions (150→75), retains strongest signals
        tf.keras.layers.MaxPooling2D((2, 2), name="pool1"),

        # ── BLOCK 2: Texture Detection ──────────────────────
        tf.keras.layers.Conv2D(64, (3, 3), padding="same", activation="relu",
                               name="conv2"),
        tf.keras.layers.BatchNormalization(name="bn2"),
        tf.keras.layers.MaxPooling2D((2, 2), name="pool2"),

        # ── BLOCK 3: Shape / Region Detection ───────────────
        tf.keras.layers.Conv2D(128, (3, 3), padding="same", activation="relu",
                               name="conv3"),
        tf.keras.layers.BatchNormalization(name="bn3"),
        tf.keras.layers.MaxPooling2D((2, 2), name="pool3"),

        # ── BLOCK 4: High-Level Feature Composition ─────────
        tf.keras.layers.Conv2D(128, (3, 3), padding="same", activation="relu",
                               name="conv4"),
        tf.keras.layers.BatchNormalization(name="bn4"),
        tf.keras.layers.MaxPooling2D((2, 2), name="pool4"),

        # ── FLATTEN: 3D → 1D ────────────────────────────────
        # Converts feature maps (H×W×C) to a single vector for Dense layers
        tf.keras.layers.Flatten(name="flatten"),

        # ── FULLY CONNECTED LAYERS ───────────────────────────
        # Dense(512): learns global relationships between all features
        tf.keras.layers.Dense(512, activation="relu", name="fc1"),
        # Dropout: randomly zeros 50% of neurons → prevents overfitting
        tf.keras.layers.Dropout(0.5, name="dropout"),

        # ── OUTPUT LAYER ─────────────────────────────────────
        # num_classes neurons; Softmax converts logits → probability distribution
        tf.keras.layers.Dense(num_classes, activation="softmax", name="output"),

    ], name="CNN_Classifier")

    return model


def compile_model(model: tf.keras.Model, learning_rate=1e-3) -> tf.keras.Model:
    """Compiles the model with Adam optimizer and categorical cross-entropy."""
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


def save_architecture_plot(model, save_path):
    """Save a visual diagram of the model architecture."""
    try:
        tf.keras.utils.plot_model(
            model,
            to_file=save_path,
            show_shapes=True,
            show_layer_names=True,
            rankdir="TB",
            dpi=96,
        )
        print(f"  [Saved] {save_path}")
    except Exception as e:
        print(f"  [Info] Could not save architecture plot: {e}")
        print("         Install graphviz + pydot for visual diagrams.")


def run_model_creation(num_classes=6):
    print("\n" + "=" * 60)
    print("TASK 4: CNN MODEL CREATION")
    print("=" * 60)

    model = build_cnn(num_classes=num_classes)
    model = compile_model(model)

    print("\n  Model Summary:")
    model.summary()

    print(f"\n  Total Parameters    : {model.count_params():,}")
    trainable = sum(tf.size(w).numpy() for w in model.trainable_weights)
    print(f"  Trainable Params    : {trainable:,}")

    print("\n  Optimizer           : Adam (lr=0.001)")
    print("  Loss Function       : Sparse Categorical Cross-Entropy")
    print("  Evaluation Metric   : Accuracy")

    # Try to save architecture diagram
    save_architecture_plot(model, os.path.join(OUTPUT_DIR, "model_architecture.png"))

    print("\n  ✅ Model created and compiled.")
    return model


if __name__ == "__main__":
    run_model_creation(num_classes=6)
