"""
Task 3: Image Preprocessing
=============================
Prepares image data for CNN training:
  - Resizes images to a fixed size (150×150)
  - Normalizes pixel values to [0, 1]
  - Splits into training / validation / test sets
  - Applies data augmentation on training set

HOW TO USE:
    Set DATA_DIR to your dataset root folder.
    Run this script — it returns tf.data Datasets ready for model training.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.model_selection import train_test_split
from PIL import Image
import warnings
warnings.filterwarnings("ignore")

# ─── CONFIG ───────────────────────────────────────────────────────────────────
DATA_DIR    = "data"       # ← Root folder with class subfolders
OUTPUT_DIR  = "outputs"
IMG_SIZE    = (150, 150)   # Resize target
BATCH_SIZE  = 32
SEED        = 42
VAL_SPLIT   = 0.15         # 15% validation
TEST_SPLIT  = 0.15         # 15% test  (from original data)
# ──────────────────────────────────────────────────────────────────────────────

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ─── DATA AUGMENTATION ────────────────────────────────────────────────────────
augmentation_layer = tf.keras.Sequential([
    tf.keras.layers.RandomFlip("horizontal"),
    tf.keras.layers.RandomRotation(0.15),
    tf.keras.layers.RandomZoom(0.1),
    tf.keras.layers.RandomTranslation(0.1, 0.1),
    tf.keras.layers.RandomContrast(0.1),
], name="augmentation")


def load_dataset_from_directory(data_dir, img_size=IMG_SIZE, batch_size=BATCH_SIZE):
    """
    Loads images from folder structure using tf.keras.
    Returns: train_ds, val_ds, class_names
    """
    print(f"\n  Loading dataset from: {data_dir}")
    print(f"  Image size : {img_size}")
    print(f"  Batch size : {batch_size}")

    # Full dataset (without test split yet)
    full_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        image_size=img_size,
        batch_size=batch_size,
        label_mode="int",
        shuffle=True,
        seed=SEED,
    )

    class_names = full_ds.class_names
    n_batches   = tf.data.experimental.cardinality(full_ds).numpy()

    # Manual split: 70% train / 15% val / 15% test
    n_test  = max(1, int(n_batches * TEST_SPLIT))
    n_val   = max(1, int(n_batches * VAL_SPLIT))
    n_train = n_batches - n_test - n_val

    train_ds = full_ds.take(n_train)
    val_ds   = full_ds.skip(n_train).take(n_val)
    test_ds  = full_ds.skip(n_train + n_val)

    print(f"\n  Class Names  : {class_names}")
    print(f"  Train batches: {n_train}  (~{n_train * batch_size} images)")
    print(f"  Val   batches: {n_val}   (~{n_val  * batch_size} images)")
    print(f"  Test  batches: {n_test}  (~{n_test  * batch_size} images)")

    return train_ds, val_ds, test_ds, class_names


def normalize(image, label):
    """Scale pixel values from [0, 255] → [0.0, 1.0]."""
    image = tf.cast(image, tf.float32) / 255.0
    return image, label


def apply_augmentation(image, label):
    """Apply augmentation only to training images."""
    image = augmentation_layer(image, training=True)
    return image, label


def build_pipelines(train_ds, val_ds, test_ds):
    """
    Applies normalization + augmentation and adds prefetch for performance.
    """
    AUTOTUNE = tf.data.AUTOTUNE

    train_ds = (train_ds
                .map(normalize,           num_parallel_calls=AUTOTUNE)
                .map(apply_augmentation,  num_parallel_calls=AUTOTUNE)
                .cache()
                .prefetch(AUTOTUNE))

    val_ds   = (val_ds
                .map(normalize, num_parallel_calls=AUTOTUNE)
                .cache()
                .prefetch(AUTOTUNE))

    test_ds  = (test_ds
                .map(normalize, num_parallel_calls=AUTOTUNE)
                .prefetch(AUTOTUNE))

    return train_ds, val_ds, test_ds


def visualize_augmentation(train_ds, class_names, save_path):
    """Shows original vs augmented versions of a sample image."""
    for images, labels in train_ds.take(1):
        # Un-augmented sample (raw normalized)
        sample_img = images[0].numpy()
        sample_lbl = class_names[labels[0].numpy()]
        break

    # Apply augmentation multiple times
    sample_tensor = tf.expand_dims(
        tf.cast(sample_img * 255, tf.float32), axis=0)
    augmented = [
        augmentation_layer(sample_tensor, training=True)[0].numpy() / 255.0
        for _ in range(5)
    ]

    fig, axes = plt.subplots(1, 6, figsize=(18, 3))
    fig.suptitle(f"Augmentation Demo  (class: {sample_lbl})",
                 fontsize=12, fontweight="bold")

    axes[0].imshow(np.clip(sample_img, 0, 1))
    axes[0].set_title("Original", fontsize=9)
    axes[0].axis("off")

    for i, aug in enumerate(augmented):
        axes[i + 1].imshow(np.clip(aug, 0, 1))
        axes[i + 1].set_title(f"Augmented {i+1}", fontsize=9)
        axes[i + 1].axis("off")

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [Saved] {save_path}")


def run_preprocessing(data_dir=DATA_DIR):
    print("\n" + "=" * 60)
    print("TASK 3: IMAGE PREPROCESSING")
    print("=" * 60)

    if not os.path.exists(data_dir):
        print(f"\n  ⚠  DATA_DIR '{data_dir}' not found.")
        print("     Update DATA_DIR at the top of this script.")
        print("     Returning None — model training will be skipped.\n")
        return None, None, None, None

    raw_train, raw_val, raw_test, class_names = load_dataset_from_directory(data_dir)
    train_ds, val_ds, test_ds = build_pipelines(raw_train, raw_val, raw_test)

    print("\n  Preprocessing Steps Applied:")
    print("    ✅ Resize       → 150 × 150 px")
    print("    ✅ Normalize    → pixel values scaled to [0.0, 1.0]")
    print("    ✅ Train split  → 70% train / 15% val / 15% test")
    print("    ✅ Augmentation → flip, rotate, zoom, translate, contrast")

    visualize_augmentation(
        train_ds, class_names,
        os.path.join(OUTPUT_DIR, "augmentation_demo.png")
    )

    print("\n  ✅ Preprocessing complete.")
    return train_ds, val_ds, test_ds, class_names


if __name__ == "__main__":
    run_preprocessing()
