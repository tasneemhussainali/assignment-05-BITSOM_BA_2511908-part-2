"""
Task 2: Dataset Exploration
============================
Analyzes the image dataset:
- Number of classes
- Number of images per class
- Sample images from each class
- Image dimensions
- Class imbalance check

HOW TO USE:
    Set DATA_DIR to the root of your dataset folder.
    Expected structure:
        data/
          ├── buildings/   (*.jpg / *.png)
          ├── forest/
          ├── glacier/
          ├── mountain/
          ├── sea/
          └── street/
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from PIL import Image
from collections import Counter
import warnings
warnings.filterwarnings("ignore")

# ─── CONFIG ───────────────────────────────────────────────────────────────────
DATA_DIR = "data"          # ← Change to your dataset root folder
OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)
# ──────────────────────────────────────────────────────────────────────────────


def get_class_info(data_dir):
    """Scan dataset folder and return class names + image counts."""
    classes = sorted([
        d for d in os.listdir(data_dir)
        if os.path.isdir(os.path.join(data_dir, d))
        and not d.startswith(".")
    ])
    class_counts = {}
    for cls in classes:
        cls_path = os.path.join(data_dir, cls)
        images = [
            f for f in os.listdir(cls_path)
            if f.lower().endswith((".jpg", ".jpeg", ".png", ".bmp", ".webp"))
        ]
        class_counts[cls] = len(images)
    return classes, class_counts


def sample_image_dimensions(data_dir, classes, n_samples=20):
    """Sample image dimensions across all classes."""
    dims = []
    for cls in classes:
        cls_path = os.path.join(data_dir, cls)
        imgs = [f for f in os.listdir(cls_path)
                if f.lower().endswith((".jpg", ".jpeg", ".png"))][:n_samples]
        for img_name in imgs:
            try:
                img = Image.open(os.path.join(cls_path, img_name))
                dims.append(img.size + (len(img.getbands()),))  # (W, H, C)
            except Exception:
                pass
    return dims


def plot_class_distribution(class_counts, save_path):
    """Bar chart of images per class."""
    classes = list(class_counts.keys())
    counts  = list(class_counts.values())
    total   = sum(counts)
    colors  = plt.cm.Set2(np.linspace(0, 1, len(classes)))

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Dataset Class Distribution", fontsize=14, fontweight="bold")

    # Bar chart
    bars = axes[0].bar(classes, counts, color=colors, edgecolor="white", linewidth=1.2)
    axes[0].set_title("Images per Class")
    axes[0].set_xlabel("Class")
    axes[0].set_ylabel("Number of Images")
    axes[0].tick_params(axis="x", rotation=30)
    for bar, count in zip(bars, counts):
        axes[0].text(bar.get_x() + bar.get_width() / 2,
                     bar.get_height() + 10,
                     str(count), ha="center", va="bottom", fontsize=9)

    # Pie chart
    axes[1].pie(counts, labels=classes, autopct="%1.1f%%",
                colors=colors, startangle=140,
                wedgeprops={"edgecolor": "white", "linewidth": 1.5})
    axes[1].set_title(f"Class Proportions  (Total: {total:,} images)")

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [Saved] {save_path}")


def plot_sample_images(data_dir, classes, save_path, n_per_class=3):
    """Show n_per_class sample images from each class."""
    fig, axes = plt.subplots(len(classes), n_per_class,
                             figsize=(n_per_class * 3, len(classes) * 3))
    fig.suptitle("Sample Images per Class", fontsize=14, fontweight="bold", y=1.01)

    for row, cls in enumerate(classes):
        cls_path = os.path.join(data_dir, cls)
        imgs = [f for f in os.listdir(cls_path)
                if f.lower().endswith((".jpg", ".jpeg", ".png"))][:n_per_class]
        for col in range(n_per_class):
            ax = axes[row][col] if len(classes) > 1 else axes[col]
            if col < len(imgs):
                img = Image.open(os.path.join(cls_path, imgs[col])).convert("RGB")
                ax.imshow(img)
            ax.axis("off")
            if col == 0:
                ax.set_ylabel(cls, fontsize=11, fontweight="bold",
                              rotation=0, labelpad=60, va="center")

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [Saved] {save_path}")


def analyze_imbalance(class_counts):
    """Compute imbalance ratio."""
    counts = list(class_counts.values())
    ratio  = max(counts) / min(counts) if min(counts) > 0 else float("inf")
    return ratio


def run_exploration(data_dir=DATA_DIR):
    print("\n" + "=" * 60)
    print("TASK 2: DATASET EXPLORATION")
    print("=" * 60)

    if not os.path.exists(data_dir):
        print(f"\n  ⚠  DATA_DIR '{data_dir}' not found.")
        print("     Update DATA_DIR at the top of this script to your dataset path.")
        print("     Running in DEMO MODE with synthetic stats.\n")
        _demo_mode()
        return

    classes, class_counts = get_class_info(data_dir)

    print(f"\n  Number of Classes : {len(classes)}")
    print(f"  Classes           : {classes}")
    print(f"\n  Images per Class:")
    for cls, cnt in class_counts.items():
        print(f"    {cls:<15} {cnt:>5} images")
    print(f"\n  Total Images      : {sum(class_counts.values()):,}")

    # Dimensions
    dims = sample_image_dimensions(data_dir, classes)
    if dims:
        widths  = [d[0] for d in dims]
        heights = [d[1] for d in dims]
        channels= [d[2] for d in dims]
        print(f"\n  Image Dimensions (sampled {len(dims)} images):")
        print(f"    Width  : min={min(widths)}, max={max(widths)}, avg={np.mean(widths):.0f}")
        print(f"    Height : min={min(heights)}, max={max(heights)}, avg={np.mean(heights):.0f}")
        print(f"    Channels: {set(channels)}  (3 = RGB)")

    # Imbalance
    ratio = analyze_imbalance(class_counts)
    imbalance_level = "LOW" if ratio < 1.5 else "MODERATE" if ratio < 3 else "HIGH"
    print(f"\n  Imbalance Ratio   : {ratio:.2f}x  → {imbalance_level} imbalance")
    if ratio > 1.5:
        print("  ⚠  Consider using class_weight or augmentation to handle imbalance.")

    # Plots
    print("\n  Generating plots...")
    plot_class_distribution(class_counts, os.path.join(OUTPUT_DIR, "class_distribution.png"))
    plot_sample_images(data_dir, classes, os.path.join(OUTPUT_DIR, "sample_images.png"))

    print("\n  ✅ Exploration complete. Check the 'outputs/' folder.")


def _demo_mode():
    """Prints synthetic stats when no dataset is present."""
    class_counts = {
        "buildings": 2191, "forest": 2271, "glacier": 2404,
        "mountain": 2512, "sea": 2274, "street": 2382
    }
    classes = list(class_counts.keys())
    print(f"  [DEMO] Number of Classes : {len(classes)}")
    print(f"  [DEMO] Classes           : {classes}")
    print(f"\n  [DEMO] Images per Class:")
    for cls, cnt in class_counts.items():
        print(f"    {cls:<15} {cnt:>5} images")
    print(f"\n  [DEMO] Total Images      : {sum(class_counts.values()):,}")
    print(f"  [DEMO] Image Dimensions  : ~150×150 px, RGB (3 channels)")
    ratio = analyze_imbalance(class_counts)
    print(f"  [DEMO] Imbalance Ratio   : {ratio:.2f}x  → LOW imbalance")
    # Plot with demo data
    plot_class_distribution(class_counts, os.path.join(OUTPUT_DIR, "class_distribution.png"))
    print("\n  ✅ Demo exploration complete. Check the 'outputs/' folder.")


if __name__ == "__main__":
    run_exploration()
