"""
Task 1: Problem Identification
==============================
Dataset: Intel Image Classification (or substitute your own dataset)
- 6 classes: buildings, forest, glacier, mountain, sea, street
- Each class contains ~2,000-3,000 labeled images
"""

PROBLEM_TYPE = "Image Classification"

JUSTIFICATION = """
Problem Type: IMAGE CLASSIFICATION
===================================

The dataset contains images organized into labeled folders (one folder per class).
Each image belongs to exactly ONE category with no spatial localization required.

Why Image Classification (not others)?
---------------------------------------

1. IMAGE CLASSIFICATION ✅ (CHOSEN)
   - Each image has a single, global label (e.g., "forest", "mountain")
   - No need to locate objects within the image — the entire image = one class
   - The dataset folder structure (class_name/image.jpg) is the classic classification setup

2. Object Detection ❌
   - Would require bounding box annotations (x, y, width, height per object)
   - Used when multiple objects of different classes exist in one image
   - Our dataset has no bounding box labels

3. Semantic Segmentation ❌
   - Requires pixel-level labels (every pixel tagged with a class)
   - Far more annotation-heavy; our dataset has only image-level labels
   - Used for tasks like road/lane detection in autonomous vehicles

4. Instance Segmentation ❌
   - Extends semantic segmentation to distinguish individual object instances
   - Even more complex; requires mask annotations per object instance
   - Not applicable here

Conclusion:
-----------
Since each image has a single global label and the task is to predict which
category a new image belongs to, this is a multi-class IMAGE CLASSIFICATION
problem. CNNs are well-suited because they learn spatial hierarchies of features
(edges → textures → shapes → objects) through convolution and pooling layers.
"""

if __name__ == "__main__":
    print("=" * 60)
    print(f"PROBLEM TYPE: {PROBLEM_TYPE}")
    print("=" * 60)
    print(JUSTIFICATION)
