"""
Task 5: Model Training and Evaluation
=======================================
Trains the CNN and evaluates:
  - Training accuracy / loss curves
  - Validation accuracy / loss curves
  - Test set performance
  - Confusion matrix
  - Sample predictions on test images
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import tensorflow as tf
from sklearn.metrics import classification_report, confusion_matrix
import warnings
warnings.filterwarnings("ignore")

OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

EPOCHS     = 30
PATIENCE   = 7     # Early stopping patience


# ─── CALLBACKS ────────────────────────────────────────────────────────────────
def get_callbacks():
    return [
        # Stop training when val_loss stops improving
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=PATIENCE,
            restore_best_weights=True,
            verbose=1
        ),
        # Reduce LR when training plateaus
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=3,
            min_lr=1e-6,
            verbose=1
        ),
        # Save best model weights
        tf.keras.callbacks.ModelCheckpoint(
            filepath=os.path.join(OUTPUT_DIR, "best_model.keras"),
            monitor="val_accuracy",
            save_best_only=True,
            verbose=1
        ),
    ]


# ─── TRAINING ─────────────────────────────────────────────────────────────────
def train_model(model, train_ds, val_ds, epochs=EPOCHS):
    print(f"\n  Training for up to {epochs} epochs (early stopping enabled)...")
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        callbacks=get_callbacks(),
        verbose=1
    )
    return history


# ─── PLOT TRAINING CURVES ─────────────────────────────────────────────────────
def plot_training_curves(history, save_path):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Training & Validation Curves", fontsize=13, fontweight="bold")

    epochs_ran = range(1, len(history.history["accuracy"]) + 1)

    # Accuracy
    axes[0].plot(epochs_ran, history.history["accuracy"],
                 "b-o", markersize=4, label="Train Accuracy")
    axes[0].plot(epochs_ran, history.history["val_accuracy"],
                 "r-o", markersize=4, label="Val Accuracy")
    axes[0].set_title("Accuracy")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    # Loss
    axes[1].plot(epochs_ran, history.history["loss"],
                 "b-o", markersize=4, label="Train Loss")
    axes[1].plot(epochs_ran, history.history["val_loss"],
                 "r-o", markersize=4, label="Val Loss")
    axes[1].set_title("Loss")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [Saved] {save_path}")


# ─── EVALUATION ───────────────────────────────────────────────────────────────
def evaluate_model(model, test_ds, class_names):
    """Full evaluation: accuracy, confusion matrix, classification report."""
    print("\n  Running evaluation on test set...")

    # Collect all predictions
    y_true, y_pred_probs = [], []
    for images, labels in test_ds:
        preds = model.predict(images, verbose=0)
        y_pred_probs.extend(preds)
        y_true.extend(labels.numpy())

    y_true      = np.array(y_true)
    y_pred_probs= np.array(y_pred_probs)
    y_pred      = np.argmax(y_pred_probs, axis=1)

    # Overall accuracy
    acc = np.mean(y_true == y_pred)
    print(f"\n  Test Accuracy : {acc:.4f}  ({acc*100:.2f}%)")

    # Per-class report
    print("\n  Classification Report:")
    print(classification_report(y_true, y_pred, target_names=class_names))

    return y_true, y_pred, y_pred_probs


def plot_confusion_matrix(y_true, y_pred, class_names, save_path):
    cm = confusion_matrix(y_true, y_pred)
    cm_pct = cm.astype(float) / cm.sum(axis=1, keepdims=True) * 100  # row-normalized

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle("Confusion Matrix", fontsize=13, fontweight="bold")

    # Raw counts
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names,
                ax=axes[0], linewidths=0.5)
    axes[0].set_title("Raw Counts")
    axes[0].set_xlabel("Predicted")
    axes[0].set_ylabel("Actual")
    axes[0].tick_params(axis="x", rotation=30)

    # Percentage (row-normalized)
    sns.heatmap(cm_pct, annot=True, fmt=".1f", cmap="Greens",
                xticklabels=class_names, yticklabels=class_names,
                ax=axes[1], linewidths=0.5)
    axes[1].set_title("Row-Normalized (%)")
    axes[1].set_xlabel("Predicted")
    axes[1].set_ylabel("Actual")
    axes[1].tick_params(axis="x", rotation=30)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [Saved] {save_path}")


def plot_sample_predictions(model, test_ds, class_names, save_path, n=16):
    """Show a grid of test images with predicted vs actual labels."""
    images_list, labels_list = [], []
    for imgs, lbls in test_ds.take(2):
        images_list.append(imgs.numpy())
        labels_list.append(lbls.numpy())

    images = np.concatenate(images_list, axis=0)[:n]
    labels = np.concatenate(labels_list, axis=0)[:n]
    preds  = np.argmax(model.predict(images, verbose=0), axis=1)

    cols = 4
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 3.5, rows * 3.5))
    fig.suptitle("Sample Predictions on Test Images", fontsize=13, fontweight="bold")

    for i in range(rows * cols):
        ax = axes[i // cols][i % cols] if rows > 1 else axes[i % cols]
        if i < n:
            ax.imshow(np.clip(images[i], 0, 1))
            true_lbl = class_names[labels[i]]
            pred_lbl = class_names[preds[i]]
            color    = "green" if labels[i] == preds[i] else "red"
            ax.set_title(f"True: {true_lbl}\nPred: {pred_lbl}",
                         fontsize=8, color=color, fontweight="bold")
        ax.axis("off")

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [Saved] {save_path}")


def print_final_summary(history):
    best_train_acc = max(history.history["accuracy"])
    best_val_acc   = max(history.history["val_accuracy"])
    best_val_loss  = min(history.history["val_loss"])
    epochs_ran     = len(history.history["accuracy"])

    print("\n" + "─" * 50)
    print("  TRAINING SUMMARY")
    print("─" * 50)
    print(f"  Epochs Run          : {epochs_ran}")
    print(f"  Best Train Accuracy : {best_train_acc:.4f}")
    print(f"  Best Val  Accuracy  : {best_val_acc:.4f}")
    print(f"  Best Val  Loss      : {best_val_loss:.4f}")
    print("─" * 50)


def run_training_evaluation(model, train_ds, val_ds, test_ds,
                             class_names, epochs=EPOCHS):
    print("\n" + "=" * 60)
    print("TASK 5: MODEL TRAINING AND EVALUATION")
    print("=" * 60)

    # Train
    history = train_model(model, train_ds, val_ds, epochs=epochs)
    print_final_summary(history)

    # Curves
    print("\n  Generating training curves...")
    plot_training_curves(history,
                         os.path.join(OUTPUT_DIR, "training_curves.png"))

    # Evaluate
    y_true, y_pred, _ = evaluate_model(model, test_ds, class_names)

    # Confusion matrix
    print("\n  Generating confusion matrix...")
    plot_confusion_matrix(y_true, y_pred, class_names,
                          os.path.join(OUTPUT_DIR, "confusion_matrix.png"))

    # Sample predictions
    print("\n  Generating sample predictions...")
    plot_sample_predictions(model, test_ds, class_names,
                            os.path.join(OUTPUT_DIR, "sample_predictions.png"))

    print("\n  ✅ Training and evaluation complete. Check 'outputs/' folder.")
    return history


if __name__ == "__main__":
    print("  Run main.py to execute the full pipeline.")
